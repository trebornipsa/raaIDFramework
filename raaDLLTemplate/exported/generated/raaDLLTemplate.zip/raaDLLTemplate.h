#pragma once
class raaDLLTemplate
{
public:
	raaDLLTemplate();
	virtual ~raaDLLTemplate();
};

